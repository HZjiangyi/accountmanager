﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace accountmanager
{
    [Serializable]
    class Account
    {
        public string Name;
        public string User;
        public string Password;
        public string EMail;
        public string Note;
        public DateTime? Date;

    }
}
