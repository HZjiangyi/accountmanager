﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace accountmanager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            Sta.dictionary = Sta.Deser();
            foreach (Account ac in Sta.dictionary.Values)
            {
                this.listBox1.Items.Add(ac.Name);
            }
           



        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBox1.Text;

                bool j = false;


                foreach (Account ac in Sta.dictionary.Values)
                {
                    if (ac.Name == name)
                    {
                        j = true;
                        break;
                    }
                }
            
                
                
                    if (name == "")
                    {
                        MessageBox.Show("网站名称不能为空");
                    }
                    else if (j) {
                        MessageBox.Show("已存在相同网站，请到“查询”界面修改");
                    }
                    else
                    {
                        Account account = new Account();
                        {
                            account.Name = name;
                            account.Password = textBox2.Text;
                            account.EMail = textBox3.Text;
                            account.Note = textBox4.Text;
                            account.User = textBox9.Text;
                            account.Date = DateTime.Now;

                        }
                        Sta.dictionary.Add(name, account);

                        this.listBox1.Items.Add(account.Name);

                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox9.Text = "";

                    Sta.Ser();
                        MessageBox.Show("存储成功！");
                    
                }
                   

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("串行化失败：" + ex.Message.ToString());

            }
           

        }

        

        private void button3_Click(object sender, EventArgs e)
        {

            if(textBox5.Text == "")
            {
                MessageBox.Show("请先选择一个网站");
            }
            else {
                if (MessageBox.Show("是否修改？", "确认", MessageBoxButtons.OKCancel) == DialogResult.OK)

                {
                    string name = textBox5.Text;

                    Sta.dictionary[name].User = textBox10.Text;
                    Sta.dictionary[name].Password = textBox7.Text;
                    Sta.dictionary[name].EMail = textBox6.Text;
                    Sta.dictionary[name].Note = textBox8.Text;
                    Sta.dictionary[name].Date = DateTime.Now;
                    textBox11.Text = Sta.dictionary[name].Date.ToString();
                    Sta.Ser();
                    MessageBox.Show("修改成功！");



                }
                
            }
            

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text = "Accountmanager 1.03\r\n作者 : JY\r\n E-mail :2509203371@qq.com";
            MessageBox.Show(text, "关于");
        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
           
            if(listBox1.SelectedItem == null) {
                MessageBox.Show("请先选择一个网站");
            }
            else
            {
                try
                {


                    Sta.dictionary = Sta.Deser();
                    Account ac = Sta.dictionary[this.listBox1.SelectedItem.ToString()];
                    textBox5.Text = ac.Name;
                    textBox6.Text = ac.Password;
                    textBox7.Text = ac.EMail;
                    textBox8.Text = ac.Note;
                    textBox10.Text = ac.User;
                    textBox11.Text = ac.Date.ToString();
                }
                catch (Exception ex)

                {

                    MessageBox.Show("错误：" + ex.Message.ToString());

                }
            }

        }

        private void 导入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
               
                DialogResult result = openFileDialog1.ShowDialog();
                if(result == DialogResult.OK)
                {
                    string path = openFileDialog1.FileName;
                    
                    using (FileStream fs = new FileStream(path, FileMode.Open))
                    {
                        BinaryFormatter bf = new BinaryFormatter();
                        Sta.dictionary = bf.Deserialize(fs) as Dictionary<string, Account>;
                        Sta.Ser();
                        
                    }

                    listBox1.Items.Clear();
                    foreach (Account ac in Sta.dictionary.Values)
                    {
                        this.listBox1.Items.Add(ac.Name);
                    }
                    MessageBox.Show("导入成功");

                }

                

                
            }
            catch (Exception ex)

            {

                MessageBox.Show("错误：" + ex.Message.ToString());

            }



        }

        private void 导出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = saveFileDialog1.ShowDialog();
                if(result == DialogResult.OK)
                {
                    Sta.Ser(saveFileDialog1.FileName);
                    MessageBox.Show("导出成功");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("错误：" + ex.Message.ToString());
            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            if (MessageBox.Show("是否删除？", "确认", MessageBoxButtons.OKCancel) == DialogResult.OK)
                

            {
                try
                {
                    string name = textBox5.Text;
                    Sta.dictionary.Remove(name);
                    Sta.Ser();
                    listBox1.Items.Clear();
                    foreach (Account ac in Sta.dictionary.Values)
                    {
                        this.listBox1.Items.Add(ac.Name);
                    }
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";




                    MessageBox.Show("删除成功！");
                }
                catch (Exception ex)

                {

                    MessageBox.Show("错误：" + ex.Message.ToString());

                }
            }
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://gitee.com/HZjiangyi/accountmanager/blob/master/README.md");
        }
    }
}
