﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Windows.Forms;

namespace accountmanager
{
    class Sta
    {
       
        public static Dictionary<string, Account> dictionary;
        public static string filePath = Directory.GetCurrentDirectory() + "/binaryFile.txt";

        public static void Ser()
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Create)) {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, Sta.dictionary);
            }
                
            
        }
        public static Dictionary<string, Account> Deser()
        {
            try
            {
               using(FileStream fs = new FileStream(filePath, FileMode.Open)){
                    BinaryFormatter bf = new BinaryFormatter();
                    Dictionary<string, Account> dic = bf.Deserialize(fs) as Dictionary<string, Account>;
                    return dic;
                }

            }
            catch(Exception)
            {
                
                return new Dictionary<string, Account>();
                

            }
        }
        public static void Ser(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, Sta.dictionary);
            }


        }
    }
}
